package com.clairvoyance.clairvoyance

class AccountDataManager {
    
}
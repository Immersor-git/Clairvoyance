package com.clairvoyance.clairvoyance

enum class DataType {
    TEXT, DATE, NUMBER, IMAGE, AUDIO, CHECKBOX, EXCEPTION
}
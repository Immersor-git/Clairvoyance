//package com.clairvoyance.clairvoyance
//
//interface DataFieldClickListener {
//    fun <T> editDataField(dataField: DataField<T>)
//    fun <T> removeDataField(dataField: DataField<T>)
//}
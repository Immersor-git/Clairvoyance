package com.clairvoyance.clairvoyance

class TaskManager {
    fun getArchive() : Task {
        TODO()
    }
}